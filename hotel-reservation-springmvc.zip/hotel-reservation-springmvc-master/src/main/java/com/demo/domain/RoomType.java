package com.demo.domain;

public enum RoomType {
    Economy, Balcony, Business, Luxury
}
